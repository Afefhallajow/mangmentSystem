package mangemtSystemJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MangemtSystemJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MangemtSystemJavaApplication.class, args);
	}

}
