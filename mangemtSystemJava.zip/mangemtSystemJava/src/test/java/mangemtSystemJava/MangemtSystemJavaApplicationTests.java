package mangemtSystemJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MangemtSystemJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
